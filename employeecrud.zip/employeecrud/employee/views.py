from django.shortcuts import render,HttpResponse,redirect
from .models import Employee
from .forms import EmployeeForm

# Create your views here.
def home(request):
    emps=Employee.objects.all();
    return render(request,'index1.html',{'emps_list':emps})
    
def upload(request):
    #GET localhost:8000/upload
    upload=EmployeeForm() #empty BookForm displayed , new instance 
    
    #POST - now BookForm filled fields and submitted
    if request.method=='POST':
        upload=EmployeeForm(request.POST,request.FILES)
        
        if upload.is_valid():
            upload.save()
            return redirect('home')
        else:
            return HttpResponse("<h2>Error: You have not filled correct information</h2>")
    
    else:
        return render(request,'upload.html',{'upload_form':upload})
        

def update_emp(request,emp_id):
    
    emp_id=int(emp_id)
    
    try:
        emp_select=Employee.objects.get(id=emp_id)
    except Employee.DoesNotExist:
        return redirect('home')
    
    emp_form=EmployeeForm(request.POST or None,instance=emp_select)
    if emp_form.is_valid():
        emp_form.save()
        return redirect('home')
    else:
        return render(request,'upload.html',{'upload_form':emp_form})
    

def delete_emp(request,emp_id):
    emp_id=int(emp_id)
    
    try:
        emp_select=Employee.objects.get(id=emp_id)
    except Employee.DoesNotExist:
        return redirect('home')

    emp_select.delete()
    return redirect('home')


        

