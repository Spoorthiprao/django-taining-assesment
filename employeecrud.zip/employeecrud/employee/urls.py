from django.contrib import admin
from django.urls import path,include
from . import views
from employeecrud.settings import DEBUG, STATIC_URL, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static



urlpatterns = [
    path('', views.home, name='home'),
    path('upload',views.upload,name='upload'),
    path('update/<int:emp_id>',views.update_emp),
    path('delete/<int:emp_id>',views.delete_emp),

]



if DEBUG:
    urlpatterns += static(MEDIA_URL, document_root = MEDIA_ROOT)