from django.db import models


class Art(models.Model):
    artist_name=models.CharField(max_length=100)
    artist_age=models.IntegerField()
    artist_email=models.EmailField(max_length=100)

    
    
    def __str__(self):
        return self.artist_name