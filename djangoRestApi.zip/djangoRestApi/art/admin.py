from django.contrib import admin
from .models import Art

admin.site.register(Art)