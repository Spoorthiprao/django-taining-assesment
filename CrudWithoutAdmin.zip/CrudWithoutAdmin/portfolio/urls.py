from django.contrib import admin
from django.urls import path,include
from . import views
from CrudWithoutAdmin.settings import DEBUG, STATIC_URL
from django.conf.urls.static import static



urlpatterns = [
    path('', views.home, name='home'),
    path('upload',views.upload,name='upload'),
    path('update/<int:port_id>',views.update_portfolio),
    path('delete/<int:port_id>',views.delete_portfolio),

]



