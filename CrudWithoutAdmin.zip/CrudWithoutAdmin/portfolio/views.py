from django.shortcuts import render,HttpResponse,redirect
from .models import Portfolio
from .forms import PortfolioForm

# Create your views here.
def home(request):
    port=Portfolio.objects.all();
    return render(request,'index.html',{'port':port})
    
def upload(request):
    
    upload=PortfolioForm() #empty BookForm displayed , new instance 
    
    #POST - now BookForm filled fields and submitted
    if request.method=='POST':
        upload=PortfolioForm(request.POST,request.FILES)
        
        if upload.is_valid():
            upload.save()
            return redirect('home')
        else:
            return HttpResponse("<h2>Error: You have not filled correct information</h2>")
    
    else:
        return render(request,'upload.html',{'upload_form':upload})
        

def update_portfolio(request,port_id):
    
    port_id=int(port_id)
    
    try:
        port_select=Portfolio.objects.get(id=port_id)
    except Portfolio.DoesNotExist:
        return redirect('home')
    
    port_form=PortfolioForm(request.POST or None,instance=port_select)
    if port_form.is_valid():
        port_form.save()
        return redirect('home')
    else:
        return render(request,'upload.html',{'upload_form':port_form})
    

def delete_portfolio(request,port_id):
    port_id=int(port_id)
    
    try:
        port_select=Portfolio.objects.get(id=port_id)
    except Portfolio.DoesNotExist:
        return redirect('home')

    port_select.delete()
    return redirect('home')


        
